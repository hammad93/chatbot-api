import warnings

from jaraco.logging import *

warnings.warn("Use jaraco.logging package", DeprecationWarning)
